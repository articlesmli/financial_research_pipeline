from __future__ import annotations

import logging
import os.path
import platform
import threading
from typing import TYPE_CHECKING

from watchdog.events import (
    DirAttribEvent,
    DirCreatedEvent,
    DirDeletedEvent,
    DirModifiedEvent,
    DirMovedEvent,
    EventsLostEvent,
    FileAttribEvent,
    FileCreatedEvent,
    FileDeletedEvent,
    FileModifiedEvent,
    FileMovedEvent,
    generate_sub_created_events,
    generate_sub_moved_events,
)
from watchdog.observers.api import DEFAULT_EMITTER_TIMEOUT, DEFAULT_OBSERVER_TIMEOUT, BaseObserver, EventEmitter
from watchdog.observers.winapi import WATCHDOG_FILE_NOTIFY_FLAGS, DirectoryChangeReader, _require_notify_filter

if TYPE_CHECKING:
    from watchdog.events import FileSystemEvent
    from watchdog.observers.api import EventQueue, ObservedWatch
    from watchdog.utils import Seconds


logger = logging.getLogger(__name__)


class WindowsApiEmitter(EventEmitter):
    """Windows API-based emitter that uses ``ReadDirectoryChangesW`` or
    ``ReadDirectoryChangesExW`` to detect file system changes for a watch.

    :param notify_filter:
        ``dwNotifyFilter`` bitmask for this watch. See :class:`WindowsApiObserver`.
    :type notify_filter:
        ``int``
    """

    def __init__(
        self,
        event_queue: EventQueue,
        watch: ObservedWatch,
        *,
        timeout: Seconds = DEFAULT_EMITTER_TIMEOUT,
        event_filter: list[type[FileSystemEvent]] | None = None,
        notify_filter: int = WATCHDOG_FILE_NOTIFY_FLAGS,
    ) -> None:
        super().__init__(event_queue, watch, timeout=timeout, event_filter=event_filter)
        self.notify_filter = _require_notify_filter(notify_filter)
        self._lock = threading.RLock()
        self._reader: DirectoryChangeReader | None = None
        # The two halves of a rename are not guaranteed to reach one
        # get_events() batch, so the pairing outlives a queue_events() call.
        self._last_renamed_src_path = ""

    def on_thread_start(self) -> None:
        with self._lock:
            assert self._reader is None
            reader = DirectoryChangeReader(
                self.watch.path,
                recursive=self.watch.is_recursive,
                notify_filter=self.notify_filter,
            )
            self._reader = reader
        reader.start()

    if platform.python_implementation() == "PyPy":

        def start(self) -> None:
            """PyPy needs some time before receiving events, see #792."""
            from time import sleep

            super().start()
            sleep(0.01)

    def on_thread_stop(self) -> None:
        with self._lock:
            reader = self._reader
            self._reader = None
        if reader is not None:
            reader.stop()

    def queue_events(self, timeout: Seconds) -> None:
        with self._lock:
            reader = self._reader
        if reader is None:
            return  # reader has been stopped
        should_stop = False
        for winapi_event in reader.get_events(timeout):
            src_path = os.path.join(self.watch.path, winapi_event.src_path)

            if winapi_event.is_renamed_old:
                self._last_renamed_src_path = src_path
            elif winapi_event.is_renamed_new:
                dest_path = src_path
                src_path = self._last_renamed_src_path
                self._last_renamed_src_path = ""
                if os.path.isdir(dest_path):
                    self.queue_event(DirMovedEvent(src_path, dest_path))
                    if self.watch.is_recursive:
                        for sub_moved_event in generate_sub_moved_events(src_path, dest_path):
                            self.queue_event(sub_moved_event)
                else:
                    self.queue_event(FileMovedEvent(src_path, dest_path))
            elif winapi_event.is_attrib:
                self.queue_event((DirAttribEvent if os.path.isdir(src_path) else FileAttribEvent)(src_path))
            elif winapi_event.is_modified:
                self.queue_event((DirModifiedEvent if os.path.isdir(src_path) else FileModifiedEvent)(src_path))
            elif winapi_event.is_added:
                isdir = os.path.isdir(src_path)
                self.queue_event((DirCreatedEvent if isdir else FileCreatedEvent)(src_path))
                if isdir and self.watch.is_recursive:
                    for sub_created_event in generate_sub_created_events(src_path):
                        self.queue_event(sub_created_event)
            elif winapi_event.is_removed:
                self.queue_event(FileDeletedEvent(src_path))
            elif winapi_event.is_removed_self:
                self.queue_event(DirDeletedEvent(self.watch.path))
                should_stop = True
            elif winapi_event.is_overflow:
                logger.warning(
                    "Some file system events were lost due to a buffer overflow while watching %s",
                    self.watch.path,
                )
                self.queue_event(
                    EventsLostEvent(
                        self.watch.resolved_path if self.watch.is_file else self.watch.path,
                        is_directory=not self.watch.is_file,
                    )
                )
        if should_stop:
            # watched directory was deleted, stop observer threads
            self.stop()


class WindowsApiObserver(BaseObserver):
    """Observer thread that schedules watching directories and dispatches
    calls to event handlers.

    :param timeout:
        Timeout for the observer to wait on events.
    :type timeout:
        ``Seconds``
    :param notify_filter:
        ``dwNotifyFilter`` bitmask passed to ``ReadDirectoryChangesW`` and
        ``ReadDirectoryChangesExW`` for every watch this observer creates.
        Combine the ``FILE_NOTIFY_CHANGE_*`` constants in
        :mod:`watchdog.observers.winapi`. Defaults to
        :data:`~watchdog.observers.winapi.WATCHDOG_FILE_NOTIFY_FLAGS`, which
        includes ``FILE_NOTIFY_CHANGE_LAST_ACCESS``. Access-time updates can
        be far more frequent than content changes; mask that flag out when
        they are not useful, for example
        ``WATCHDOG_FILE_NOTIFY_FLAGS & ~FILE_NOTIFY_CHANGE_LAST_ACCESS``.
        Watches that need different masks belong on different observers.
    :type notify_filter:
        ``int``
    """

    def __init__(
        self,
        *,
        timeout: Seconds = DEFAULT_OBSERVER_TIMEOUT,
        notify_filter: int = WATCHDOG_FILE_NOTIFY_FLAGS,
    ) -> None:
        super().__init__(
            WindowsApiEmitter,
            timeout=timeout,
            notify_filter=_require_notify_filter(notify_filter),
        )
