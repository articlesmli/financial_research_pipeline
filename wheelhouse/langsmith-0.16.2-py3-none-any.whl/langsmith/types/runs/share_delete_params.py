# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ShareDeleteParams"]


class ShareDeleteParams(TypedDict, total=False):
    session_id: Required[str]
    """session_id is the tracing project UUID containing the trace."""
