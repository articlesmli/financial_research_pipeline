# Copyright 2026 The Kubernetes Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

__project__ = "kubernetes_aio"
# The version is auto-updated. Please do not edit.
__version__ = "37.0.3"

import kubernetes.aio.client as client
import kubernetes.aio.config as config
import kubernetes.aio.dynamic as dynamic
import kubernetes.aio.leaderelection as leaderelection
import kubernetes.aio.stream as stream
import kubernetes.aio.utils as utils
import kubernetes.aio.watch as watch

__all__ = ["client", "config", "dynamic", "leaderelection", "stream", "utils", "watch"]
